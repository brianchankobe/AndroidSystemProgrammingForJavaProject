package com.example.mapdemo;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public abstract class LifecycleLoggingActivity extends Activity {

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(getClass().getSimpleName(), "onCreate()");
        if (savedInstanceState == null) {
            Log.d(getClass().getSimpleName(), "activity created new");
        } else {
            Log.d(getClass().getSimpleName(), "activity restarted");
        }
    }

    public void onRestart() { /* you fill in here. */
        super.onRestart();
        Log.d(getClass().getSimpleName(), "onRestart()");
    }

    public void onStart() { /* you fill in here. */
        super.onStart();
        Log.d(getClass().getSimpleName(), "onStart()");
    }

    public void onResume() { /* you fill in here. */
        super.onResume();
        Log.d(getClass().getSimpleName(), "onResume()");
    }

    public void onPause() { /* you fill in here. */
        super.onPause();
        Log.d(getClass().getSimpleName(), "onPause()");
    }

    public void onStop() { /* you fill in here. */
        super.onStop();
        Log.d(getClass().getSimpleName(), "onStop()");
    }

    public void onDestroy() { /* you fill in here. */
        super.onDestroy();
        Log.d(getClass().getSimpleName(), "onDestroy()");
    }
}
