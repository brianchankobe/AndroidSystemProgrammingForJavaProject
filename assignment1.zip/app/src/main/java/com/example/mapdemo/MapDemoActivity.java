package com.example.mapdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MapDemoActivity extends LifecycleLoggingActivity {

    private EditText latitudeField;
    private EditText longitudeField;
    private String tagName = "MapDemo";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        latitudeField = (EditText) findViewById(R.id.latitude);
        longitudeField = (EditText) findViewById(R.id.longitude);
    }

    public void showLocation(View view) {
        String latitudeText = latitudeField.getText().toString();
        String longtitudeText = longitudeField.getText().toString();

        //当经纬度不为空
        if (latitudeText.length() != 0 && longtitudeText.length() != 0) {
            Double latitudeVal = Double.parseDouble(latitudeText); //纬度
            Double longtitudeVal = Double.parseDouble(longtitudeText); //经线

            Log.d(tagName, "latitude: " + latitudeVal + " Longtitude: " + longtitudeVal);

            // Build the intent.
            //String text = Integer.toString(latitudeVal) + "," + Integer.toString(longtitudeVal);
            String text = "geo:" + Double.toString(latitudeVal) + "," + Double.toString(longtitudeVal);
            Uri location = Uri.parse(text);
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, location);
            // Try to invoke the intent.
            try {
                startActivity(mapIntent);
            } catch (ActivityNotFoundException e) {
                // Define what your app should do if no activity can handle the intent.
                Log.d(tagName, "No activity handle intent");
            }

/*            if (latitudeVal >= 0 && latitudeVal <= 90 && longtitudeVal >= 0 && longtitudeVal <= 180) {
                // Build the intent.
                String text = Integer.toString(latitudeVal) + "," + Integer.toString(longtitudeVal);
                Uri location = Uri.parse("google.streetview:cbll="+text);
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, location);
                // Try to invoke the intent.
                try {
                    startActivity(mapIntent);
                } catch (ActivityNotFoundException e) {
                    // Define what your app should do if no activity can handle the intent.
                    Log.d(tagName, "No activity handle intent");
                }
            } else {
                Toast.makeText(getApplicationContext(), "location exceeds range of longtitude and latitude", Toast.LENGTH_SHORT).show();
            }*/
        } else{
            Toast.makeText(getApplicationContext(), "error: location missing.", Toast.LENGTH_SHORT).show();
        }
    }
}